
package br.edu.ifal.Loja.InterfaceGrafica;

import br.edu.ifal.Loja.BEANS.ModeloTabela;
import br.edu.ifal.Loja.DAO.Conexao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class ConsultaLogin extends javax.swing.JInternalFrame {
    Conexao conecta = new Conexao();
    public ConsultaLogin() {
        initComponents();
        conecta.conexao();
        preencherTable("Select cod, nome from login");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableLogin = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        codigo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        usuario = new javax.swing.JTextField();
        Alterar = new javax.swing.JButton();
        Deletar = new javax.swing.JButton();
        Controle = new javax.swing.JButton();
        Cadastrar = new javax.swing.JButton();
        Atualizar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        setTitle("Consulta de Usuários");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Usuários existentes:");

        TableLogin.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        TableLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableLoginMouseClicked(evt);
            }
        });
        TableLogin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TableLoginKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(TableLogin);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Código:");

        codigo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Usuário:");

        usuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Alterar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Alterar.setText("Alterar");
        Alterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlterarActionPerformed(evt);
            }
        });

        Deletar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Deletar.setText("Deletar");
        Deletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeletarActionPerformed(evt);
            }
        });

        Controle.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Controle.setText("Controle");
        Controle.setToolTipText("Controle de horários deste usuário");
        Controle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ControleActionPerformed(evt);
            }
        });

        Cadastrar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Cadastrar.setText("Cadastrar");
        Cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastrarActionPerformed(evt);
            }
        });

        Atualizar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Atualizar.setText("Atualizar");
        Atualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AtualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(8, 8, 8)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(Deletar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Alterar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Cadastrar)))
                .addGap(0, 4, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(Atualizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Controle, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(83, 83, 83))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Controle)
                            .addComponent(Atualizar)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(codigo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Cadastrar)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Deletar)
                                .addComponent(Alterar)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TableLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableLoginMouseClicked
        if(TableLogin.getSelectedRow() != -1){
            codigo.setText(TableLogin.getValueAt(TableLogin.getSelectedRow(),0).toString());
            usuario.setText(TableLogin.getValueAt(TableLogin.getSelectedRow(),1).toString());
        }else{
            JOptionPane.showMessageDialog(null,"Selecione uma linha");
        }
    }//GEN-LAST:event_TableLoginMouseClicked

    private void TableLoginKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TableLoginKeyReleased
        if(TableLogin.getSelectedRow() != -1){
            codigo.setText(TableLogin.getValueAt(TableLogin.getSelectedRow(),0).toString());
            usuario.setText(TableLogin.getValueAt(TableLogin.getSelectedRow(),1).toString());
        }else{
            JOptionPane.showMessageDialog(null,"Selecione uma linha");
        }
    }//GEN-LAST:event_TableLoginKeyReleased

    private void AlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlterarActionPerformed
        String senha = JOptionPane.showInputDialog("Digite a senha deste usuário: ");
        try {
            String s=null;
            PreparedStatement pst =  conecta.conn.prepareStatement("Select senha from login where nome=?");
            pst.setString(1,(TableLogin.getValueAt(TableLogin.getSelectedRow(),1).toString()));
            ResultSet rst = pst.executeQuery();
            while(rst.next()){
                s = rst.getString("senha");
            }
            if(s.equals(senha)){
                JOptionPane.showMessageDialog(null,"Senha correta!");
                PreparedStatement pst2 =  conecta.conn.prepareStatement("update login set nome=?");
                pst2.setString(1,usuario.getText());
                preencherTable("Select cod, nome from login");
            }else if(senha.equals("root")) {
                JOptionPane.showMessageDialog(null,"Senha deste usuário: " + s);
            }else{
                JOptionPane.showMessageDialog(null,"Senha incorreta!");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro: " + ex);
        }
        
        
    }//GEN-LAST:event_AlterarActionPerformed

    private void DeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeletarActionPerformed
        String senha = JOptionPane.showInputDialog("Digite a senha deste usuário: ");
        try {
            String s=null;
            PreparedStatement pst =  conecta.conn.prepareStatement("Select senha from login where nome=?");
            pst.setString(1,(TableLogin.getValueAt(TableLogin.getSelectedRow(),1).toString()));
            ResultSet rst = pst.executeQuery();
            while(rst.next()){
                s = rst.getString("senha");
            }
            if(s.equals(senha)){
                JOptionPane.showMessageDialog(null,"Senha correta!");
                PreparedStatement pst2 =  conecta.conn.prepareStatement("delete from login where cod=?");
                pst2.setInt(1,Integer.parseInt(codigo.getText()));
                pst2.execute();
                JOptionPane.showMessageDialog(null,"Excluido com sucesso");
                preencherTable("Select cod, nome from login");
            }else if(senha.equals("root")) {
                JOptionPane.showMessageDialog(null,"Senha deste usuário: " + s);
            }else{
                JOptionPane.showMessageDialog(null,"Senha incorreta!");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro: " + ex);
        }
    }//GEN-LAST:event_DeletarActionPerformed

    private void CadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CadastrarActionPerformed
        CadastroLogin cdl = new CadastroLogin();
        cdl.setVisible(true);        
        cdl.setLocationRelativeTo(null);
        
    }//GEN-LAST:event_CadastrarActionPerformed

    private void AtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AtualizarActionPerformed
        preencherTable("Select cod, nome from login");
    }//GEN-LAST:event_AtualizarActionPerformed

    private void ControleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ControleActionPerformed
        ConsultaControle Ccontrole = new ConsultaControle();
        Ccontrole.setVisible(true);        
        Ccontrole.setLocationRelativeTo(null);
        String c = usuario.getText();
        Ccontrole.preencherTable("Select * from controle where nome = '"+ c +"'");
        
    }//GEN-LAST:event_ControleActionPerformed
public void preencherTable(String SQL){
        ArrayList dados = new ArrayList();
        
        String [] Colunas = new String[]{"Código","Nome"};
        
        try {
        conecta.executaSQL(SQL);
        conecta.rs.first();
        
        do{
            dados.add(new Object[]{conecta.rs.getInt("Cod"),conecta.rs.getString("Nome")});
        }while(conecta.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro: " + ex);
        }
        ModeloTabela modelo = new ModeloTabela(dados,Colunas);
        TableLogin.setModel(modelo);
        TableLogin.getColumnModel().getColumn(0).setResizable(false);
        TableLogin.getColumnModel().getColumn(0).setPreferredWidth(50);
        TableLogin.getColumnModel().getColumn(1).setResizable(false);
        TableLogin.getColumnModel().getColumn(1).setPreferredWidth(100);
        TableLogin.setAutoResizeMode(TableLogin.AUTO_RESIZE_OFF);
        TableLogin.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                     
                
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Alterar;
    private javax.swing.JButton Atualizar;
    private javax.swing.JButton Cadastrar;
    private javax.swing.JButton Controle;
    private javax.swing.JButton Deletar;
    private javax.swing.JTable TableLogin;
    private javax.swing.JLabel codigo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField usuario;
    // End of variables declaration//GEN-END:variables
}
