
package br.edu.ifal.Loja.InterfaceGrafica;

import br.edu.ifal.Loja.DAO.Conexao;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class CadastroLogin extends javax.swing.JFrame {
    Conexao conecta = new Conexao();
    public CadastroLogin() {
        initComponents();
        conecta.conexao();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        senhaText = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        nome = new javax.swing.JTextField();
        Cadastrar = new javax.swing.JButton();
        confirmasenhaText = new javax.swing.JPasswordField();
        Alterar = new javax.swing.JButton();
        Deletar = new javax.swing.JButton();
        limpar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro Login");

        senhaText.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Senha:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Usuário:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Confirme:");

        nome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Cadastrar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Cadastrar.setText("Cadastrar");
        Cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastrarActionPerformed(evt);
            }
        });

        confirmasenhaText.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Alterar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Alterar.setText("Alterar");
        Alterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlterarActionPerformed(evt);
            }
        });

        Deletar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Deletar.setText("Deletar");
        Deletar.setToolTipText("");
        Deletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeletarActionPerformed(evt);
            }
        });

        limpar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        limpar.setText("Limpar");
        limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limparActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(nome, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE)
                    .addComponent(senhaText)
                    .addComponent(confirmasenhaText))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(limpar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Deletar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Alterar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Cadastrar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(senhaText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(confirmasenhaText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cadastrar)
                    .addComponent(Deletar)
                    .addComponent(Alterar)
                    .addComponent(limpar)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CadastrarActionPerformed
        try {
            PreparedStatement pst = conecta.conn.prepareStatement("insert into login (Nome,Senha) VALUES (?, ?)");
            pst.setString(1, nome.getText());
            String aux1 = new String (senhaText.getPassword());
            String aux2 = new String (confirmasenhaText.getPassword());
            if(aux1.equals(aux2)){
                pst.setString(2, aux1); 
            }else{
                JOptionPane.showMessageDialog(null, "Campo 'confirmar' incorreto");
            }
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Inserido com sucesso!");
            senhaText.setText(null);
            confirmasenhaText.setText(null);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Não foi inserido!\n Erro: " + ex.getMessage());
        }
        
    }//GEN-LAST:event_CadastrarActionPerformed

    private void AlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlterarActionPerformed
        try {
            PreparedStatement pst =  conecta.conn.prepareStatement("update login set senha=? where nome=?");
            String aux1 = new String (senhaText.getPassword());
            String aux2 = new String (confirmasenhaText.getPassword());
            if(aux1.equals(aux2)){
                pst.setString(1, aux1); 
            }else{
                JOptionPane.showMessageDialog(null, "Campo 'confirmar' incorreto");
            }
            pst.setString(2,nome.getText() );
            pst.execute();
            JOptionPane.showMessageDialog(null,"Senha alterada com sucesso");
            senhaText.setText(null);
            confirmasenhaText.setText(null);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Alterar. Verifique se o usuário está correto, ou erro: \n" + ex);
        }
    }//GEN-LAST:event_AlterarActionPerformed

    private void DeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeletarActionPerformed
        try{   
            PreparedStatement pst =  conecta.conn.prepareStatement("delete from login where senha=? or nome=?");
            pst.setString(1,new String (senhaText.getPassword()));
            pst.setString(2,nome.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Excluido com sucesso");
            senhaText.setText(null);
            confirmasenhaText.setText(null);
        }catch(SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Alterar: \n" + ex);
        }
    }//GEN-LAST:event_DeletarActionPerformed

    private void limparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limparActionPerformed
        nome.setText(null);
        senhaText.setText(null);
        confirmasenhaText.setText(null);
    }//GEN-LAST:event_limparActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Alterar;
    private javax.swing.JButton Cadastrar;
    private javax.swing.JButton Deletar;
    private javax.swing.JPasswordField confirmasenhaText;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton limpar;
    private javax.swing.JTextField nome;
    private javax.swing.JPasswordField senhaText;
    // End of variables declaration//GEN-END:variables
}
